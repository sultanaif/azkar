export interface Zekr {
  text: string;
  count: number;
}

export type AzkarType = 'morning' | 'evening';